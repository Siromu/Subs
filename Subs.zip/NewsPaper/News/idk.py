from forms import SubscribeForm

SubscribeForm.category.get